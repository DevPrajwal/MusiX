package com.androidauthority.a2dgame;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.view.*;
import android.content.res.*;


public class GameView extends SurfaceView implements SurfaceHolder.Callback {
    public MainThread thread;
    public MainBall mainBall;
	public Activity activity;
	public float intensity = 0;
	private balls Ball;
	public Bitmap sImage = null;
	private boolean ft = true;
	private Paint pnt = new Paint();
	private int screenWidth = Resources.getSystem().getDisplayMetrics().widthPixels;
    private int screenHeight = Resources.getSystem().getDisplayMetrics().heightPixels;
	public int alarm = 300;
	public boolean touched = true;
	public int bassX = screenWidth/8;;
	public int bassY = screenHeight/2;
	public int speedX = screenWidth - (screenWidth/8);;
	public int speedY = screenHeight - (screenHeight/2);
	private Paint pntBass = new Paint();
	private Paint pntBack = new Paint();
	private Paint pntTxt = new Paint();
	
    public GameView(Context context) {
        super(context);

        getHolder().addCallback(this);

        thread = new MainThread(getHolder(), this);

        setFocusable(true);
		
		mainBall = new MainBall();
		mainBall.thread = this.thread;
	
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

	@Override
	public void setOnTouchListener(View.OnTouchListener MediaPlayer)
	{
		// TODO: Implement this method
		super.setOnTouchListener(MediaPlayer);
	}

    

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        
		if((ft == true))
		{
			thread.setRunning(true);
        	thread.start();
			ft = false;
		}
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        /*boolean retry = true;
        while (retry) {
            try {
                thread.setRunning(false);
                thread.join();

        } catch(InterruptedException e){
            e.printStackTrace();
        }
        retry = false;
    }*/
    }

    public void update() {
	
        mainBall.update();
		if(mainBall.Balls.size() != 0)
		{
		for(int i = 0;i < mainBall.Balls.size();i++){
			if(mainBall.Balls.get(i) != null){
				mainBall.Balls.get(i).update();

			}
		}
		}
		if(alarm > 0)
		{
			alarm --;
			//pntBass.setAlpha(alarm * 2);
			pntBass.setColor(Color.WHITE);
			pntTxt.setAlpha(Integer.MAX_VALUE);
			pntTxt.setColor(Color.BLACK);
		}else{
			pntBass.setAlpha(0);
		}
	
    }

    @Override
    public void draw(Canvas canvas)
    {

        super.draw(canvas);
		
        if(canvas!=null) {
			if(sImage != null)
			{
				pnt.setAlpha(400);
				canvas.drawBitmap(sImage,(screenWidth/2)-(sImage.getWidth()/2),(screenHeight/2)-(sImage.getHeight()/2),pnt);
			}
			if(mainBall.Balls.size() != 0)
			{
				
			for(int i = 0;i < mainBall.Balls.size();i++){
				if(mainBall.Balls.get(i) != null){
					mainBall.Balls.get(i).draw(canvas);

				}
			}
			}
			drawVal(bassX,bassY,canvas,"bass");
			drawVal(speedX,speedY,canvas,"speed");
			mainBall.draw(canvas);
        }
		
    }
	public void drawVal(int x,int y,Canvas canvas,String str)
	{
		/*pntBack.setColor(Color.BLACK);
		pntBack.setAlpha(alarm/2);
		canvas.drawRect(0,0,screenWidth,screenHeight,pntBack);*/
		
		if((str == "bass") && (alarm > 0))
		{
		
			int bassSize = screenWidth/8;
			int lineSize = (screenWidth/4)/4;
			
			pntTxt.setTextSize(bassSize/2);
			pntBass.setAlpha(alarm/2);
			
			canvas.drawRect(bassX - lineSize,(bassSize)/2,bassX + lineSize,screenHeight-((bassSize)/2),pntBass);
			canvas.drawCircle(bassX,bassY,bassSize,pntBass);
			canvas.drawText("BASS",bassX-(bassSize/2)-(bassSize/4)+(bassSize/8),bassY+(bassSize/3),pntTxt);
			
		}
		
		if((str == "speed") && (alarm > 0))
		{

			int speedSize = screenWidth/8;
			int lineSize = (screenWidth/4)/4;

			pntTxt.setTextSize(speedSize/2);
			pntBass.setAlpha(alarm/2);

			canvas.drawRect(speedX - lineSize,(speedSize)/2,speedX + lineSize,screenHeight-((speedSize)/2),pntBass);
			canvas.drawCircle(speedX,speedY,speedSize,pntBass);
			canvas.drawText("SPEED",speedX-(speedSize/2)-(speedSize/4),speedY+(speedSize/3),pntTxt);

		}
	}
    public void setInt(float i)
	{
		this.intensity = i;

	}

}







