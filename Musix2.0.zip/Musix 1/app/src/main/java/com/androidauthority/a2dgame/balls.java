package com.androidauthority.a2dgame;
import android.graphics.*;
import android.content.res.*;
import android.util.*;
import android.content.*;

public class balls
{
	public int B;
	private int screenWidth = Resources.getSystem().getDisplayMetrics().widthPixels;
    private int screenHeight = Resources.getSystem().getDisplayMetrics().heightPixels;
	public int x = screenWidth/2;
	public int y = screenHeight/2;
    private int xVelocity;
    private int yVelocity;
    private int ballSize = 0;
	private Paint pnt = new Paint();
	private int c = 0;
	private float intensity = 0;
	private int intint = 0;
	private int intox = 1;
	private int intoy = 1;
	private double randomx = 1;
	private double randomy = 1;
	private int startx = 0;
	private int starty = 0;
	public int dir = 1;
	public int shape = 0;
	private float prevInt = 0;
	private float intDif = 0;
	private int mul = 1;
	private int intdif = 1;
	private static final float GESTURE_THRESHOLD_DP = 16.0f;
	private final float scale = Resources.getSystem().getDisplayMetrics().density;
	private int mG = 0;
		
	
	
	public balls(int B,int x,int y,int xVelocity,int yVelocity,double direc,int color,double shape){
		this.B = B;
		this.x = x;
		this.y = y;
		this.startx = x;
		this.starty = y;
		this.xVelocity = xVelocity;
		this.yVelocity = yVelocity;
		this.c = color;
		if(direc > 0.5)
		{
			this.dir = 1;
		}
		if(direc <= 0.5)
		{
			this.dir = -1;
		}
		if((shape > 0.0) && (shape < 0.35))
		{
			this.shape = 0;
		}
		if((shape > 0.35) && (shape < 0.65))
		{
			this.shape = 1;
		}
		if(shape > 0.65)
		{
			this.shape = 2;
		}
		if(B == 0)
		{
			if(x == screenWidth)
			{
				x = screenWidth - ballSize; 
			}
			if(x == 0)
				{
					x = ballSize; 
				}
			if(y == screenHeight)
				{
					x = screenHeight - ballSize; 
				}
			if(y == screenHeight)
				{
					y = ballSize; 
				}
		}
	}
	
	public void update(){
			mG = (int) (GESTURE_THRESHOLD_DP * scale + 0.5f);
			ballSize = mG*2;
		//physics
		intDif = prevInt - intensity;
		if(intDif < 0.0)
		{
			mul = -1;
		}else{
			mul = 1;
		}
		intdif = Float.floatToIntBits(intDif)/1000000*mul;
		
		//MainBall behaviour
		if(B == 0)
		{
			if(intint > 0.98)
			{
				x = (startx) + (xVelocity*intdif)/1000* intox;
				y = (starty) + (yVelocity*intdif)/1000* intoy;
			}
		}
		//normalball behaviour
		if(B == 1)
		{
			x += (xVelocity * intdif)/1000;
            y += (yVelocity * intdif)/1000;
             if (x < ballSize) {
			 x = ballSize + xVelocity;
			 xVelocity = xVelocity*-1;
			 }
			 if (x > screenWidth - ballSize) {
			 x = screenWidth - ballSize - xVelocity;
			 xVelocity = xVelocity*-1;
			 }
			 if (y > screenHeight - ballSize) {
			 y = screenHeight - ballSize - yVelocity;
			 yVelocity = yVelocity*-1;
			 }
			 if (y < ballSize) {
			 y = ballSize + yVelocity;
			 yVelocity = yVelocity*-1;
			 }
		}
		//cornerslide behaviour
		if(B == 2)
		{	if(((x >= ballSize) && (x <= screenWidth - ballSize) && (y <= screenHeight - ballSize) && (y >= ballSize)))
			{
			x += (xVelocity * intdif)/1000;
            y += (yVelocity * intdif)/1000;
			}else{
				xVelocity = mG/3;
				yVelocity = mG/3;
			}
			
			if (x < ballSize) {
				//x = ballSize + xVelocity;
				x += xVelocity * 0;
				y += (yVelocity * intdif)/1000 * dir;
			}
			if (x > screenWidth - ballSize) {
				//x = screenWidth - ballSize - xVelocity;
				x += xVelocity * 0;
				y += (yVelocity * intdif)/1000 * (dir*-1);
			}
			if (y > screenHeight - ballSize) {
				//y = screenHeight - ballSize - yVelocity;
				x += (xVelocity * intdif)/1000 * (dir);
				y += yVelocity * 0;
			}
			if (y < ballSize) {
				//y = ballSize + yVelocity;
				x += (xVelocity * intdif)/1000 * (dir*-1);
				y += yVelocity * 0;
			}
			
		}
		//bigball behaviour
		if(B == 3)
		{
			/*int[] mot = moveToPoint(screenWidth/2,screenHeight/2,(xVelocity+yVelocity)/2);
			x = mot[0];
			y = mot[1];*/
			x += xVelocity;
			y += yVelocity;
		}
		
		intint = Float.floatToIntBits(intensity)/1000000;
		//Log.d("intint",String.valueOf(intint));
		//paint
		
		pnt.setColor(c);
		pnt.setAlpha(intdif*30);
	}
	
	public void draw(Canvas canvas){
		if(shape == 0)
		{
			canvas.drawCircle(x,y,ballSize,pnt);
		}
		if(shape == 1)
		{
			canvas.drawRect(x - ballSize,y - ballSize,x + ballSize,y + ballSize,pnt);
		}
		if(shape == 2)
		{
			canvas.drawRoundRect(x - ballSize,y - ballSize,x + ballSize,y + ballSize,x,y,pnt);
		}
	}
	//intensity
	public void setInt(float i)
	{
		prevInt = intensity;
		this.intensity = i;
		//just for random position of this

		randomx = Math.random();
		randomy = Math.random();
		if(randomx > 0.5)
		{
			intox = 1;
		}
		if(randomx < 0.5)
		{
			intox = -1;
		}
		if(randomy > 0.5)
		{
			intoy = 1;
		}
		if(randomy < 0.5)
		{
			intoy = -1;
		}
		//Log.d("random",String.valueOf(into));

	}
	public int[] moveToPoint(int X2,int Y2,int spd)
	{
		int[] ret = new int[1];
		int xDis = X2 - x;
		int yDis = Y2 - y;
		x += spd*(xDis/yDis);
		y += spd*(yDis/xDis);
		ret[0] = x;
		ret[1] = y;
		return ret;
	}
}

