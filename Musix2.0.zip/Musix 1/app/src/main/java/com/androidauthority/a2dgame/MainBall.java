package com.androidauthority.a2dgame;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.media.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.support.v7.appcompat.*;
import android.graphics.*;
import java.util.*;
import android.util.*;


public class MainBall {
   
	private int screenWidth = Resources.getSystem().getDisplayMetrics().widthPixels;
    private int screenHeight = Resources.getSystem().getDisplayMetrics().heightPixels;
	private int x = screenWidth/2;
	private int y = screenHeight/2;
    private int xVelocity = 5;
    private int yVelocity = 5;
    public int ballSize = 0;
	private Paint pnt = new Paint();
	private int c;
	private float intensity = 0;
	private int intint = 0;
	private int intox = 1;
	private int intoy = 1;
	private double randomx = 1;
	private double randomy = 1;
	public boolean playing = false;
	private Paint pnt1 = new Paint();
	private Paint pntPlaying = new Paint();
	private int b = 0;
	public ArrayList<balls> Balls = (ArrayList) new ArrayList<balls>();
	private int timer = 300;
	private int rcolor;
	private float prevInt = 0;
	private float intDif = 0;
	private boolean b3 = true;
	private double rs = Math.random();
	private int intdif = 0;
	private static final float GESTURE_THRESHOLD_DP = 16.0f;
	private final float scale = Resources.getSystem().getDisplayMetrics().density;
	private int mG = 0;
	private int find = 1;
	public boolean touched = false;
	public int touchCount = 0;
	private double touchTime = 0;
	public MainThread thread;
	public int dir = 0;
	private Paint pnt2 = new Paint();
	private int progAlpha = 1000;
	private Paint pntStr = new Paint();
	private int touchCountt = 0;
	
    public MainBall () {
		double rc = Math.random();
		if(rc <= 0.5){rcolor = (int)(Math.random()*99999*-1);}
		if(rc > 0.5){rcolor = (int)(Math.random()*99999*1);}
		for(int i = 0;i < 10;i++){
			Balls.add(i,null);
			
		}
    }
	
    public void draw(Canvas canvas) {
		
			canvas.drawCircle(x,y,ballSize,pnt);
			canvas.drawCircle(x,y,((ballSize*2)*intdif)/1000,pnt1);
		
			if(playing == true){
					canvas.drawRect(x-mG/3,y-(mG+mG/2),x-mG,y+(mG+mG/2),pntPlaying);
					canvas.drawRect(x+mG/3,y-(mG+mG/2),x+mG,y+(mG+mG/2),pntPlaying);
			}
			
			if(playing == false){
				canvas.drawLine(x-mG/2,y-mG,x-mG/2,y+mG,pntPlaying);
				canvas.drawLine(x-mG/2,y-mG,x+mG,y,pntPlaying);
				canvas.drawLine(x-mG/2,y+mG,x+mG,y,pntPlaying);
			}
			checkprog(canvas);
    }
	
    public void update() {
			
			//physics
			/*for(int i = 0;i < Balls.size();i++)
			{
				Log.d("no of balls",String.valueOf(Balls.get(i)));
		
			}*/
			mG = (int) ((GESTURE_THRESHOLD_DP * scale + 0.5f));
			
			ballSize = (mG*2); 
			//Log.d("mg",String.valueOf(mG));
			intDif = prevInt - intensity;
			intdif = Float.floatToIntBits(intDif)/1000000;
			//Log.d("intDif",String.valueOf(Math.abs(intDif*10)));
			if((intint > 0.98) && ((intDif >= 0.1) || (intDif <= -0.1)))
			{
				x = (screenWidth/2) + ((xVelocity*intint)/4000)* intox;
				y = (screenHeight/2) + ((yVelocity*intint)/4000)* intoy;
			}
			if(touchTime > 0)
			{
				touchTime --;
			}else{
				touchCount = 0;
				touchCountt = 0;
				dir = 0;
			}
			timer --;
			//Log.d("timer",String.valueOf(timer));
			if(timer <= 0)
			{
				timer = 300;
				if((intDif >= 0.1) || (intDif <= -0.1))
				{
				change();
				rs = Math.random();
				}else{
					find = 1;
					destroy();
				}
			}
				if((intDif >= 0.90) ||(intDif <= -0.90))
				{
					change();
					rs = Math.random();
					timer = 300;
				}
            //x += xVelocity * intint;
            //y += yVelocity * intint;
            /*if (x < ballSize) {
				x = ballSize + xVelocity;
                xVelocity = xVelocity*-1;
            }
			if (x > screenWidth - ballSize) {
				x = screenWidth - ballSize - xVelocity;
				xVelocity = xVelocity*-1;
			}
            if (y > screenHeight - ballSize) {
				y = screenHeight - ballSize - yVelocity;
                yVelocity = yVelocity*-1;
            }
			if (y < ballSize) {
				y = ballSize + yVelocity;
				yVelocity = yVelocity*-1;
			}*/
			//check and destroy
			if(b == 3){
			for(int i = 0;i < Balls.size();i++){
				if(Balls.get(i) != null)
				{
				if((Balls.get(i).x >= (screenWidth/2)-ballSize) && (Balls.get(i).x <= (screenWidth/2)+ballSize) && (Balls.get(i).y == screenHeight/2))
				{
					Balls.set(i,null);
				}else{
						if((Balls.get(i).x == (screenWidth/2)) && (Balls.get(i).y >= (screenHeight/2)-ballSize) && (Balls.get(i).y <= (screenHeight/2)+ballSize))
							{
								Balls.set(i,null);
							}
				}
				}
			}
			}
			//paint stuff
			c = rcolor;
			pnt1.setColor(c);
			pnt1.setAlpha(25*intint);
			pnt.setColor(c);
			pnt2.setColor(c);
			pnt2.setAlpha(progAlpha);
			pntPlaying.setColor(Color.WHITE);
			pntStr.setColor(Color.WHITE);
			pntStr.setTextSize(mG*3);
			intint = Float.floatToIntBits(intensity)/1000000;
			//Log.d("intint1",String.valueOf(10*intint/1000));
			//Log.d("int",String.valueOf(400+(alpha/2)));
			//pnt.setAlpha((intint*500));
			if((touched == false) && (progAlpha > 0))
				{
					progAlpha -= thread.averageFPS*10;
				}
			if(touched == true)
			{
				progAlpha = 1000;
			}
    	}
		//Capture intensity
		public void setInt(float i)
		{
			prevInt = intensity;
			this.intensity = i;
			//just for random position of this
			randomx = Math.random();
			randomy = Math.random();
			if(randomx > 0.5)
			{
				intox = 1;
			}
			if(randomx < 0.5)
			{
				intox = -1;
			}
			if(randomy > 0.5)
			{
				intoy = 1;
			}
			if(randomy < 0.5)
			{
				intoy = -1;
			}
			//Log.d("random",String.valueOf(into));
			//hit
			if(b == 3)
			{ 
				checkB3();
			}
			
		}
		public void setPlaying(boolean isPlaying)
		{
			this.playing = isPlaying;
		}
		public void change(){
			destroy();
			double random = Math.random();
			if((random >= 0.0) && (random < 0.25))
			{
				b = 0;
			}
			if((random >= 0.25) && (random < 0.50))
			{
				b = 1;
			}
			if((random >= 0.50) && (random < 0.75))
			{
				b = 2;
			}
			if((random >= 0.75) && (random < 1.0))
			{
				b = 3;
			}
			switch(b)
			{
				case 0 : position(); break;
				case 1 : split(); break;
				case 2 : split(); break;
				case 3 : hit(); break;
				
			}
			Log.d("b",String.valueOf(b));
		}
		public void split(){
			double random = Math.random();
			double rc = Math.random();
			if(b == 1)
			{
			if(rc <= 0.5){rcolor = (int)(Math.random()*99999*-1);
				for(int i = 0;i < 10;i++){
					Balls.set(i,new balls(b,x,y,i,10-i,random,rcolor,rs));
				}
			}
			if(rc > 0.5){rcolor = (int)(Math.random()*99999*1);
				for(int i = 0;i < 10;i++){
					Balls.set(i,new balls(b,x,y,-i,-(10-i),random,rcolor,rs));
				}
			}
			}
			if(b == 2)
			{
				if(rc <= 0.5){rcolor = (int)(Math.random()*99999*-1);
					
				}
				if(rc > 0.5){rcolor = (int)(Math.random()*99999*1);
					
				}
				for(int i = 0;i < 5;i++){
					Balls.set(i,new balls(b,x,y,-i*2,-(10-(i*2)),random,rcolor,rs));
				}
				for(int i = 0;i < 5;i++){
					Balls.set(5+i,new balls(b,x,y,i*2,10-i*2,random,rcolor,rs));
				}
			}
		}
		public void position(){
			double random = Math.random();
			double rc = Math.random();
			if(rc <= 0.5){rcolor = (int)(Math.random()*99999*-1);}
			if(rc > 0.5){rcolor = (int)(Math.random()*99999*1);}
			for(int i = 0;i < 3;i++)
			{
				for(int j = 0;j < 3;j++)
				{
					Balls.set(j+(3*(i)),new balls(b,(screenWidth/2)*(j),(screenHeight/2)*(i),5,5,random,rcolor,rs));
				}
		
			}
		}
		public void hit()
		{
			double random = Math.random();
			double rposition = Math.random();
			int imax = 0;
			float ilimit;
			int iInto;
			if(intDif < 0.0)
			{
				iInto = -1;
			}else{
				iInto = 1;
			}
			ilimit = intDif*iInto;
			if((ilimit > 0.0)&&(ilimit < 0.25)){
				imax = 1;
			}
			if((ilimit > 0.25)&&(ilimit < 0.50)){
				imax = 2;
			}
			if((ilimit > 0.50)&&(ilimit < 0.75)){
				imax = 3;
			}
			if(ilimit > 0.75){
				imax = 4;
			}
			//Log.d("i",String.valueOf(ilimit));
					for(int i = 0;i < imax;i++)
				{
							double rc = Math.random();
							if(rc <= 0.5){rcolor = (int)(Math.random()*99999*-1);}
							if(rc > 0.5){rcolor = (int)(Math.random()*99999*1);}
							int[] pos = new int[8];
							pos[0] = 0;
							pos[1] = (screenHeight/2);
							pos[2] = screenWidth/2;
							pos[3] = 0;
							pos[4] = screenWidth;
							pos[5] = screenHeight/2;
							pos[6] = screenWidth/2;
							pos[7] = screenHeight;
							int[] odd = new int[4];
							odd[0] = 0;
							odd[1] = 2;
							odd[2] = 4;
							odd[3] = 6;
							int[] xv = new int[4];
							xv[0] = mG+(mG-1);
							xv[1] = 0;
							xv[2] = -(mG+(mG-1));
							xv[3] = 0;
							int[] yv = new int[4];
							yv[0] = 0;
							yv[1] = mG+(mG-1);
							yv[2] = 0;
							yv[3] = -(mG+(mG-1));
							
							Balls.set(i,new balls(b,pos[odd[i]],pos[odd[i]+1],xv[i],yv[i],random,rcolor,rs));
							b3 = false;
			}
		}
		public void checkB3(){
			for(int i = 0;i < Balls.size();i++){
				if(Balls.get(i) == null){
					b3 = true;
				}else{
					if(Balls.get(i) != null)
					{
						b3 = false;break;
					}
				}
			}
			if(b3 == true)
			{
				rs = Math.random();
				hit();
			}
		}
		public void destroy(){
			for(int i = 0;i < Balls.size();i++){
				if(Balls.get(i) != null){
					Balls.set(i,null);
					
				}
			}
		}
		public void setTouched(boolean istouched){
			this.touched = istouched;
			if(thread != null)
			{
				touchCount ++;
				touchTime = thread.averageFPS/2;
				touchCountt += 1*dir;
				if(touchCount > 1)
				{
				change();
				rs = Math.random();
				timer = 300;
				}
			}
			
		}
		private void checkprog(Canvas canvas){
			if((touchCount > 1) && (dir == 1))
			{
				canvas.drawOval(screenWidth/2,0,screenWidth+screenWidth/2,screenHeight,pnt2);
				canvas.drawText(String.valueOf((touchCountt+1)*10)+"s",(screenWidth/4)*3,screenHeight/2,pntStr);
			}
			if((touchCount > 1) && (dir == -1))
			{
				canvas.drawOval(-screenWidth/2,0,screenWidth/2,screenHeight,pnt2);
				canvas.drawText(String.valueOf((touchCountt-1)*10)+"s",(screenWidth/4)*0,screenHeight/2,pntStr);
			}
		}
}




