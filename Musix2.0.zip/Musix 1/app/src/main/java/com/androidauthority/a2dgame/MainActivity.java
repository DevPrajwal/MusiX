package com.androidauthority.a2dgame;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.os.*;
import android.content.*;
import android.net.*;
import android.media.*;
import android.view.*;
import android.widget.*;
import android.media.audiofx.*;
import android.util.*;
import android.support.v4.content.*;
import android.*;
import android.content.pm.*;
import android.support.v4.app.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.app.*;
import android.content.res.*;

public class MainActivity extends Activity {
	
	Intent myFileIntent;
	private MediaPlayer player;
	private PlaybackParams playbackParams;
	private Runnable runnable;
	private Handler handler;
	private GameView gview;
	private Visualizer audioOutput = null;
	private BassBoost bass;
	private MediaMetadataRetriever metaRetriver;
	private byte[] art;
	private Bitmap songImage;
	private Uri uri = null;
	private float x1 = 0;
	private float x2 = 0;
	private float y1 = 0;
	private float y2 = 0;
	private boolean paused = false;
	private int tC = 0;
	private int screenWidth = Resources.getSystem().getDisplayMetrics().widthPixels;
    private int screenHeight = Resources.getSystem().getDisplayMetrics().heightPixels;
	public short val = (short) 500;
	public float spd = 1;
	private float y = 0;
	private float bassYdiff = 0;
	public float intensity = 0; //intensity is a value between 0 and 1. The intensity in this case is the system output volume
	//public float frequency = 0; i thought it is useful but duh
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		AlertDialog aD = createDialog();
		check_Permission(aD);
		gview = new GameView(this);
        setContentView(gview);
		if(gview != null)
		{
			val = (short) 500;
			spd = 1f;
		}
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		setRequestedOrientation(1);
		if(player == null)
		{
			if(getIntent() != null)
			{
				uri = getIntent().getData();
			}
			if(uri != null)
			{
				init(uri);
			}else{
				if(uri == null)
				{
					startIntent();
				}
			}
		}
    }
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		// TODO: Implement this method
		if(requestCode == 10)
		{
			if(resultCode == RESULT_OK)
			{	try{
				uri = data.getData();
				init(uri);
				}catch(Exception e)
				{
					Toast.makeText(this,e.toString(),300);
				}finally{
					if(uri == null)
					{
						Toast.makeText(this,"please enter a valid file, either audio/video",300);
						startIntent();
					}
				}
			}
		}
	}
	
	public void check_Permission(AlertDialog aD)
	{
		if (ContextCompat.checkSelfPermission(this,
											  Manifest.permission.MODIFY_AUDIO_SETTINGS)
			!= PackageManager.PERMISSION_GRANTED) {
			ActivityCompat.requestPermissions(this,
											  new String[]{Manifest.permission.MODIFY_AUDIO_SETTINGS},
											  10);
			aD.show();
		}
		if (ContextCompat.checkSelfPermission(this,
											  Manifest.permission.RECORD_AUDIO)
			!= PackageManager.PERMISSION_GRANTED) {
			ActivityCompat.requestPermissions(this,
											  new String[]{Manifest.permission.RECORD_AUDIO},
											  10);
			aD.show();
		}
		if (ContextCompat.checkSelfPermission(this,
											  Manifest.permission.READ_EXTERNAL_STORAGE)
			!= PackageManager.PERMISSION_GRANTED) {
			ActivityCompat.requestPermissions(this,
											  new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
											  10);
			aD.show();
		}
		if (ContextCompat.checkSelfPermission(this,
											  Manifest.permission.WRITE_EXTERNAL_STORAGE)
			!= PackageManager.PERMISSION_GRANTED) {
			ActivityCompat.requestPermissions(this,
											  new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
											  10);
			aD.show();
		}
	}
	
	public void init(final Uri uri){
		try{
		if(((player != null) && player.isPlaying()))
		{
			player.stop();
			player.release();
			player = null;
			audioOutput.release();
			audioOutput = null;
			metaRetriver.release();
			setUri(null);
		}
		player = MediaPlayer.create(this,uri);
		playbackParams = new PlaybackParams();
		player.setPlaybackParams(playbackParams);
		metaRetriver = new MediaMetadataRetriever();
		metaRetriver.setDataSource(this,uri);
		bass = new BassBoost(0,player.getAudioSessionId());
		//player.start();
		update();
		createVisualizer();
		}catch(Exception e){
			Toast.makeText(this,e.toString(),300);
			destroy();
			startIntent();
		}
		try {
			if(metaRetriver.getEmbeddedPicture() != null)
			{
				art = metaRetriver.getEmbeddedPicture();
				songImage = BitmapFactory .decodeByteArray(art, 0, art.length);
			}
			//songImage.setWidth(screenWidth);
			//songImage.setHeight(screenHeight);
			gview.sImage = songImage;
		}catch(Exception e)
		{
			e.printStackTrace();
		}

		//gview.mainBall.setPlaying(true);
		player.setOnCompletionListener(new MediaPlayer.OnCompletionListener(){
				@Override
				public void onCompletion(MediaPlayer mp){
					player.stop();
					player.release();
					player = null;
					audioOutput.release();
					audioOutput = null;
					metaRetriver.release();
					setUri(null);
					startIntent();
					gview.mainBall.setPlaying(false);
				}
			});
	}
	@Override
	protected void onPause()
	{
		// TODO: Implement this method 
		super.onPause();
		if(player != null)
		{
		//gview.thread.setRunning(false);
		//gview.thread.destroy();
		paused = true;
		//gview.thread.stop();
		}
	}
	@Override
	protected void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		if((player != null) && (paused == true))
		{
		if((gview.thread.running == false))
		{
		gview.thread.setRunning(true);
        gview.thread.resume();
		}
		paused = false;
		}
	}
	
	@Override
	protected void onDestroy()
	{
		// TODO: Implement this method
		super.onDestroy();
		destroy();
	}
	public void destroy(){
		if(player != null)
		{
			player.stop();
			player.release();
			player = null;
			if(audioOutput != null)
			{
			audioOutput.release();
			audioOutput = null;
			}
			if(metaRetriver != null)
			{
			metaRetriver.release();
			}
			//startIntent();
			gview.mainBall.setPlaying(false);
			//gview.thread.setRunning(false);
			//gview.thread.destroy();
		}
	}
	private void update(){
		
	}
	
	private void startIntent(){
		if(uri == null)
		{
			Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
			intent.setType("*/*");
			startActivityForResult(intent,10);
		}
	}

	public void setUri(Uri uri)
	{
		this.uri = uri;
	}

	@Override
    public boolean onTouchEvent(MotionEvent event)
    {
		if(gview != null)
		{
			    y = gview.bassY;
			int s = screenWidth/8;
			int h = screenHeight;
			int w = screenWidth;
			
			if((y >= 0) && (y < (h/10)))
			{
				val = (short)1000;
			}
			if((y >= (h/10)) && (y < ((h/10)*2)))
			{
				val = (short)900;
			}
			if((y >= (h/10)*2) && (y < ((h/10)*3)))
			{
				val = (short)800;
			}
			if((y >= (h/10)*3) && (y < ((h/10)*4)))
			{
				val = (short)700;
			}
			if((y >= (h/10)*4) && (y < ((h/10)*5)))
			{
				val = (short)600;
			}
			if((y >= (h/10)*5) && (y < ((h/10)*6)))
			{
				val = (short)500;
			}
			if((y >= (h/10)*6) && (y < ((h/10)*7)))
			{
				val = (short)400;
			}
			if((y >= (h/10)*7) && (y < ((h/10)*8)))
			{
				val = (short)300;
			}
			if((y >= (h/10)*8) && (y < ((h/10)*9)))
			{
				val = (short)200;
			}
			if((y >= (h/10)*9) && (y <= h))
			{
				val = (short)100;
			}
			
			y = gview.speedY;
			
			if((y >= 0) && (y < (h/10)))
			{
				spd = 2f;
			}
			if((y >= (h/10)) && (y < ((h/10)*2)))
			{
				spd = 1.8f;
			}
			if((y >= (h/10)*2) && (y < ((h/10)*3)))
			{
				spd = 1.6f;
			}
			if((y >= (h/10)*3) && (y < ((h/10)*4)))
			{
				spd = 1.4f;
			}
			if((y >= (h/10)*4) && (y < ((h/10)*5)))
			{
				spd = 1.2f;
			}
			if((y >= (h/10)*5) && (y < ((h/10)*6)))
			{
				spd = 1.0f;
			}
			if((y >= (h/10)*6) && (y < ((h/10)*7)))
			{
				spd = 0.8f;
			}
			if((y >= (h/10)*7) && (y < ((h/10)*8)))
			{
				spd = 0.6f;
			}
			if((y >= (h/10)*8) && (y < ((h/10)*9)))
			{
				spd = 0.4f;
			}
			if((y >= (h/10)*9) && (y <= h))
			{
				spd = 0.2f;
			}
			player.setPlaybackParams(playbackParams);
			Log.d("spd",String.valueOf(spd));
			gview.alarm = 300;
			bass.setStrength(val);
			if(player != null)
			{
				if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) 
				{
					playbackParams.setSpeed(spd);
				}
				//Log.d("sdk",String.valueOf(Build.VERSION.SDK_INT));
			}
		}
		
		if(event.getAction() == MotionEvent.ACTION_DOWN)
		{
			x1 = event.getAxisValue(event.AXIS_X);
			y1 = event.getAxisValue(event.AXIS_Y);
			if(event.getAxisValue(event.AXIS_X) < screenWidth/2)
			{
				bassYdiff = gview.bassY - y1;
			}
			if(event.getAxisValue(event.AXIS_X) > screenWidth/2)
			{
				bassYdiff = gview.speedY - y1;
			}
		}
		
		if(event.getAction() == MotionEvent.ACTION_MOVE)
		{
			if(event.getAxisValue(event.AXIS_X) < screenWidth/2)
			{
			if((gview.bassY < (screenHeight - ((screenWidth/8)/2))) && (gview.bassY > (screenWidth/8)/2))
			{
				gview.bassY = (int) (event.getAxisValue(event.AXIS_Y) + bassYdiff);
			}else{
				if(gview.bassY >= (screenHeight - ((screenWidth/8)/2)))
				{
					gview.bassY = (screenHeight - ((screenWidth/8)/2)) - 1;
				}
				if(gview.bassY <= ((screenWidth/8)/2))
				{
					gview.bassY = ((screenWidth/8)/2) + 1;
				}
			}
			}
			
			if(event.getAxisValue(event.AXIS_X) > screenWidth/2)
			{
				if((gview.speedY < (screenHeight - ((screenWidth/8)/2))) && (gview.speedY > (screenWidth/8)/2))
				{
					gview.speedY = (int) (event.getAxisValue(event.AXIS_Y) + bassYdiff);
				}else{
					if(gview.speedY >= (screenHeight - ((screenWidth/8)/2)))
					{
						gview.speedY = (screenHeight - ((screenWidth/8)/2)) - 1;
					}
					if(gview.speedY <= ((screenWidth/8)/2))
					{
						gview.speedY = ((screenWidth/8)/2) + 1;
					}
				}
			}
		}
		
		if(event.getAction() == MotionEvent.ACTION_UP){
			gview.mainBall.setTouched(true);
			
			x2 = event.getAxisValue(event.AXIS_X);
			y2 = event.getAxisValue(event.AXIS_Y);
			
			try{
			if(gview.mainBall.touchCount > 1)
			{
				if(x2 > screenWidth/2 && !(player.getCurrentPosition() + 10000 > player.getDuration())) 
				{
					player.seekTo(player.getCurrentPosition() + 10000 * (gview.mainBall.touchCount - tC - 1));
					if(!(player.isPlaying()))
					{
						player.start();
						gview.mainBall.setPlaying(true);
					}
					gview.mainBall.dir = 1;
				}
				if(x2 < screenWidth/2  && !(player.getCurrentPosition() - 10000 < 0))
				{
					player.seekTo(player.getCurrentPosition() + -10000 * (gview.mainBall.touchCount - tC - 1));
					if(!(player.isPlaying()))
						{
							player.start();
							gview.mainBall.setPlaying(true);
						}
					gview.mainBall.dir = -1;
				}
				tC ++;
			}else{
				tC = 0;
				gview.mainBall.dir = 0;
			}
			}catch(Exception e)
			{
				Toast.makeText(this,e.toString(),300);
			}
		
		float xdif = x1 - x2;
		float ydif = y1 - y2;
		if((xdif > (screenWidth/5)) || (xdif < -(screenWidth/5)))
		{
			setUri(null);
			startIntent();
		}
		
		if((xdif < (screenWidth/5)) && (xdif > -(screenWidth/5)) && (ydif < (screenHeight/5)) && (ydif > -(screenHeight/5)))
		{
			if((x2 > ((screenWidth/2) - gview.mainBall.ballSize*2)) && ((x2 < ((screenWidth/2) + gview.mainBall.ballSize*2))) && (y2 > ((screenHeight/2) - gview.mainBall.ballSize*2)) && ((y2 < ((screenHeight/2) + gview.mainBall.ballSize*2))))
			{
				if(player != null)
				{
					boolean apply = true;
					if((player.isPlaying()) && apply == true)
					{
						player.pause();
						gview.mainBall.setPlaying(false);
						apply = false;
					}
					if((!(player.isPlaying())) && apply == true)
					{
						player.start();
						gview.mainBall.setPlaying(true);
						apply = false;
					}
				}
			}
		}
			if(event.getAxisValue(event.AXIS_X) < screenWidth/2)
			{
				if((gview.bassY < (screenHeight - ((screenWidth/8)/2))) && (gview.bassY > (screenWidth/8)/2))
				{
					gview.bassY = (int) (event.getAxisValue(event.AXIS_Y) + bassYdiff);
				}else{
					if(gview.bassY >= (screenHeight - ((screenWidth/8)/2)))
					{
						gview.bassY = (screenHeight - ((screenWidth/8)/2)) - 1;
					}
					if(gview.bassY <= ((screenWidth/8)/2))
					{
						gview.bassY = ((screenWidth/8)/2) + 1;
					}
				}
				bass.setEnabled(true);
				if(player.isPlaying())
				{
					player.pause();
					player.start();
				}
				if(!(player.isPlaying()))
				{
					player.start();
					player.pause();
				}
			}

			if(event.getAxisValue(event.AXIS_X) > screenWidth/2)
			{
				if((gview.speedY < (screenHeight - ((screenWidth/8)/2))) && (gview.speedY > (screenWidth/8)/2))
				{
					gview.speedY = (int) (event.getAxisValue(event.AXIS_Y) + bassYdiff);
				}else{
					if(gview.speedY >= (screenHeight - ((screenWidth/8)/2)))
					{
						gview.speedY = (screenHeight - ((screenWidth/8)/2)) - 1;
					}
					if(gview.speedY <= ((screenWidth/8)/2))
					{
						gview.speedY = ((screenWidth/8)/2) + 1;
					}
				}
			}
			
		}
		
        return super.onTouchEvent(event);
    }
	private void createVisualizer(){
		try{
		if(player != null)
		{
		int rate = Visualizer.getMaxCaptureRate();
		audioOutput = new Visualizer(player.getAudioSessionId()); // get output audio stream
		audioOutput.setDataCaptureListener(new Visualizer.OnDataCaptureListener() {
				@Override
				public void onWaveFormDataCapture(Visualizer visualizer, byte[] waveform, int samplingRate) {
					intensity = ((((float) waveform[0] + waveform[1023]) / 256) + 1f)/2;
					//Log.d("vis", String.valueOf(intensity));
					
					gview.setInt(intensity);
					if(gview.mainBall != null)
					{
						gview.mainBall.setInt(intensity);
					}
					for(int i = 0;i < gview.mainBall.Balls.size();i++){
						if(gview.mainBall.Balls.get(i) != null){
							gview.mainBall.Balls.get(i).setInt(intensity);

						}
					}
				}

				@Override
				public void onFftDataCapture(Visualizer visualizer, byte[] fft, int samplingRate) {
					//frequency = ((float) fft[512] + 128f) / 256;
					
					//Log.d("freq",String.valueOf(frequency));
					
				}
			},rate , true, false); // waveform not freq data
		//Log.d("rate", String.valueOf(rate));
		audioOutput.setEnabled(true);
		}
		}catch(Exception e){
			Toast.makeText(this,"Unable to initialize Visualizer, please try again or choose a valid audio/video",500);
			destroy();
			startIntent();
		}
	}
	
	private AlertDialog createDialog(){
		
	
				AlertDialog.Builder builder = new AlertDialog.Builder(this);
				builder.setTitle("Tutorial");
				builder.setMessage("Welcome to MusiX, To pause or play, tap on play button;To go forward or backward, double tap on right or left;To change the song, swipe horizontally; To keep song and app playing in background, press home button;To exit, press back button; Enjoy;)");
				builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

							@Override
							public void onClick(DialogInterface p1, int p2)
								{
									// TODO: Implement this method
								}
						});
			return builder.create();
			}
}
