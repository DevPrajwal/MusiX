# MusiX
MusiX is a music player and visualizer
